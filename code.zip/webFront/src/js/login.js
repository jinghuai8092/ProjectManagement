const loginBtn=document.getElementById('loginBtn')

loginBtn.onclick=function(){
    window.location.href="../html/index.html"
}