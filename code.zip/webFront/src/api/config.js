export const SUCC_CODE=200;

export const TIMEOUT=30000;